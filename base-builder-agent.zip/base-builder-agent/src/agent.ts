import "dotenv/config";
import Anthropic from "@anthropic-ai/sdk";
import { writeFileSync } from "node:fs";
import path from "node:path";

const SYSTEM_PROMPT = `You are a Solidity smart contract generator.
Given a plain-English spec, output ONLY a single, complete, compilable
Solidity file targeting pragma solidity ^0.8.24. Rules:
- No markdown fences, no commentary — Solidity source only.
- Prefer minimal, dependency-free implementations unless the spec asks
  for a standard like ERC-20/721/1155, in which case you may import
  from "@openzeppelin/contracts" using standard import paths.
- Include NatSpec comments and sensible require() checks.
- Do not include any deployment scripts or hardhat/foundry config —
  contract code only.`;

async function generateContract(spec: string): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "ANTHROPIC_API_KEY is not set. Add it to your .env file (see .env.example)."
    );
  }

  const client = new Anthropic({ apiKey });

  const response = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 4096,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: spec }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text content returned from Claude.");
  }
  return textBlock.text.trim();
}

async function main() {
  const spec = process.argv.slice(2).join(" ").trim();
  if (!spec) {
    console.error(
      'Usage: npm run agent -- "an ERC-20 token called Charm, symbol CHARM, 18 decimals, 1,000,000 max supply"'
    );
    process.exit(1);
  }

  console.log(`Generating contract for spec:\n  "${spec}"\n`);
  const solidity = await generateContract(spec);

  const outPath = path.join(process.cwd(), "contracts", "Generated.sol");
  writeFileSync(outPath, solidity, "utf-8");
  console.log(`Contract written to ${outPath}`);
  console.log("\nNext steps:");
  console.log("  npm run compile");
  console.log("  npm run deploy");
}

main().catch((err) => {
  console.error("Agent failed:", err.message || err);
  process.exit(1);
});
