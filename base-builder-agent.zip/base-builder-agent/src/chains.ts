import { defineChain } from "viem";
import { base, baseSepolia } from "viem/chains";
import "dotenv/config";

export type NetworkName = "base" | "base-sepolia";

export function getChain(network: NetworkName) {
  if (network === "base") return base;
  return baseSepolia;
}

export function getRpcUrl(network: NetworkName): string {
  if (network === "base") {
    return process.env.BASE_MAINNET_RPC_URL || "https://mainnet.base.org";
  }
  return process.env.BASE_SEPOLIA_RPC_URL || "https://sepolia.base.org";
}

export function currentNetwork(): NetworkName {
  const n = (process.env.NETWORK || "base-sepolia") as NetworkName;
  if (n !== "base" && n !== "base-sepolia") {
    throw new Error(`Unknown NETWORK "${n}". Use "base" or "base-sepolia".`);
  }
  return n;
}

// Re-exported in case a script wants the raw viem chain objects directly.
export { base, baseSepolia, defineChain };
