import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
// @ts-expect-error solc has no bundled types
import solc from "solc";

const CONTRACTS_DIR = path.join(process.cwd(), "contracts");
const ARTIFACTS_DIR = path.join(process.cwd(), "artifacts");

function pickContractFile(): string {
  const preferred = path.join(CONTRACTS_DIR, "Generated.sol");
  if (existsSync(preferred)) return preferred;
  const fallback = path.join(CONTRACTS_DIR, "SampleToken.sol");
  console.log("No Generated.sol found — compiling SampleToken.sol instead.");
  return fallback;
}

function compile(filePath: string) {
  const source = readFileSync(filePath, "utf-8");
  const fileName = path.basename(filePath);

  const input = {
    language: "Solidity",
    sources: {
      [fileName]: { content: source },
    },
    settings: {
      outputSelection: {
        "*": {
          "*": ["abi", "evm.bytecode.object"],
        },
      },
      optimizer: { enabled: true, runs: 200 },
    },
  };

  const output = JSON.parse(solc.compile(JSON.stringify(input)));

  if (output.errors) {
    const fatal = output.errors.filter((e: any) => e.severity === "error");
    for (const err of output.errors) console.error(err.formattedMessage);
    if (fatal.length > 0) {
      throw new Error("Compilation failed — see errors above.");
    }
  }

  const contractsInFile = output.contracts[fileName];
  const contractName = Object.keys(contractsInFile)[0];
  const compiled = contractsInFile[contractName];

  if (!existsSync(ARTIFACTS_DIR)) mkdirSync(ARTIFACTS_DIR);
  const artifactPath = path.join(ARTIFACTS_DIR, `${contractName}.json`);
  writeFileSync(
    artifactPath,
    JSON.stringify(
      { abi: compiled.abi, bytecode: "0x" + compiled.evm.bytecode.object },
      null,
      2
    )
  );

  console.log(`Compiled ${contractName} -> ${artifactPath}`);
}

compile(pickContractFile());
