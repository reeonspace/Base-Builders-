import "dotenv/config";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { getClients } from "../src/walletClient.js";

const ARTIFACTS_DIR = path.join(process.cwd(), "artifacts");

function loadArtifact() {
  if (!existsSync(ARTIFACTS_DIR)) {
    throw new Error('No artifacts found. Run "npm run compile" first.');
  }
  const files = readdirSync(ARTIFACTS_DIR).filter((f) => f.endsWith(".json"));
  if (files.length === 0) {
    throw new Error('No compiled artifacts found. Run "npm run compile" first.');
  }
  const artifactPath = path.join(ARTIFACTS_DIR, files[0]);
  const artifact = JSON.parse(readFileSync(artifactPath, "utf-8"));
  console.log(`Using artifact: ${files[0]}`);
  return artifact as { abi: any[]; bytecode: `0x${string}` };
}

async function main() {
  const { abi, bytecode } = loadArtifact();
  const { publicClient, walletClient, account, network, chain } = getClients();

  console.log(`Deploying to ${network} (chainId ${chain.id}) from ${account.address}...`);

  // NOTE: if your generated contract's constructor takes arguments,
  // pass them here, e.g. args: ["Charm", "CHARM", 1_000_000n]
  const hash = await walletClient.deployContract({
    abi,
    bytecode,
    args: [],
  });

  console.log(`Transaction sent: ${hash}`);
  console.log("Waiting for confirmation...");

  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  console.log(`Deployed at: ${receipt.contractAddress}`);

  const explorer =
    network === "base"
      ? `https://basescan.org/address/${receipt.contractAddress}`
      : `https://sepolia.basescan.org/address/${receipt.contractAddress}`;
  console.log(`View on Basescan: ${explorer}`);
}

main().catch((err) => {
  console.error("Deployment failed:", err.message || err);
  process.exit(1);
});
