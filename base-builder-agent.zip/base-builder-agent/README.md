# Base Builder Agent

An AI agent that takes a natural-language description of a smart contract,
generates Solidity code with Claude, compiles it, and deploys it to
**Base** (or **Base Sepolia** for testing) using `viem`.

## How it works

1. **Describe** the contract you want in plain English (e.g. "an ERC-20
   token called Charm with an 18-decimal supply cap of 1,000,000").
2. **Generate** — `src/agent.ts` sends your spec to the Anthropic API and
   gets back Solidity source.
3. **Compile** — `scripts/compile.ts` compiles the contract with `solc`
   and produces ABI + bytecode.
4. **Deploy** — `scripts/deploy.ts` deploys the compiled contract to Base
   using a wallet client from `viem`.

## Project structure

```
base-builder-agent/
├── contracts/
│   └── SampleToken.sol      # example starter contract
├── src/
│   ├── agent.ts             # Claude-powered contract generator
│   ├── chains.ts            # Base + Base Sepolia chain config
│   └── walletClient.ts      # viem wallet/public client setup
├── scripts/
│   ├── compile.ts           # solc compilation step
│   └── deploy.ts            # deployment script
├── .env.example
├── package.json
└── tsconfig.json
```

## Setup

```bash
npm install
cp .env.example .env
# fill in ANTHROPIC_API_KEY, PRIVATE_KEY, and RPC_URL in .env
```

## Usage

Generate a contract from a spec:

```bash
npm run agent -- "an ERC-20 token called Charm, symbol CHARM, 18 decimals, 1,000,000 max supply"
```

This writes the generated Solidity to `contracts/Generated.sol`.

Compile it:

```bash
npm run compile
```

Deploy to Base Sepolia (testnet) by default:

```bash
npm run deploy
```

Deploy to Base mainnet:

```bash
NETWORK=base npm run deploy
```

## Safety notes

- **Never commit your `.env` file** — it holds your private key. It's
  already git-ignored.
- Always deploy to **Base Sepolia** first and test thoroughly before
  touching mainnet.
- The agent generates code — review every contract yourself (or have a
  second model/auditor review it) before deploying real funds. Nothing
  here is a substitute for a proper security audit.

## Roadmap ideas

- Add automatic Slither/Mythril static analysis before deploy
- Add contract verification on Basescan after deploy
- Support multi-file contracts (e.g. importing OpenZeppelin)
- Add a simple CLI wizard instead of a single spec string
